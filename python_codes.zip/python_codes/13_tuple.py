# # tuple ele can't change
# t = (2,4,23,5)

# print(t)
# print(t[2])
# print(t[:2])

# #t[2] = 239 #--> can't change tuple value
# print(t)


#empty tuple
t1 = ()
print(t1)
#tuple with single ele
t2 = (1,) # --> wrongway (1)
print(t2)

# t3 = (,2)  --> Wrong
# print(t3)