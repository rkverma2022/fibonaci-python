class employee:
    salary = 100

    def changeSalary(self, sal):
        self.salary = sal
        print(f"{self.salary}")

    def change(self, sal):
        self.__class__.salary = sal

e = employee()
print(e.salary)

e.changeSalary(300)

print(employee.salary)

e.change(8000)

print(employee.salary)