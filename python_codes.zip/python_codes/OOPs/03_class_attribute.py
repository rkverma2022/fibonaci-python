class Employee:
    company = 'google'

Babali = Employee()
Soni = Employee()
print(Babali.company)
print(Soni.company)

#--> class attribute

Employee.company = 'microsoft'
#--> instance attribute
Babali.company = 'youtube'  
print(Babali.company)
print(Soni.company)
