import random
import matplotlib.pyplot as plt
randomNum = []
S = set()

for i in range(100):
    r = random.randint(1, 10)
    randomNum.append(r)
    S.add(r)

print(randomNum)
plt.plot(randomNum)
plt.show()
print(S)