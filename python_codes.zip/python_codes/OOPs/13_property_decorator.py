class employee:
    salary = 100
    salarybonus = 200
    #getter
    @property

    def totalSalary(self):
        return self.salary + self.salarybonus
    
    #setter
    @totalSalary.setter
    def totalSalary(self, val):
        self.salarybonus = val - self.salary
    
e = employee()
print(e.totalSalary)

e.totalSalary = 5000
print(e.salary)
print(e.salarybonus)