class person:
    company = "google"

    def getsalary(self):
        print(f"I'm getting: {self.salary}")

class employee(person):
    company = "microsoft"

    def getsalary(self):
        print(f"salary: {self.salary}")

class programmer(employee):
    
    def language(self):
        print(f"I know: {self.lang}")

p = person()
p.salary = 200
e = employee()
e.salary = 100
pr = programmer()
pr.lang = "python"
pr.salary = 999

pr.language()
pr.getsalary()

print(e.company)
