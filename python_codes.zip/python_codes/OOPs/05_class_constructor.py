class employee:
    employee = "youtube"
    def __init__(self, salary, employee):
        self.salary = salary
        self.employee = employee

        print("employee is created")
    
    def getSalary(self):
        print(f"salary is: {self.salary} {self.employee}")

mahi = employee(100, "google")

mahi.getSalary()