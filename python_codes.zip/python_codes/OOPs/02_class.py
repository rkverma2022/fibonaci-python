class RailwayForm:
    def ApplForm(self):
        print(f"Name is {self.name}")
        print(f"Train is {self.train}")

myform = RailwayForm()
myform.name = "Anushka"
myform.train = "Gaganyaan"
myform.ApplForm()