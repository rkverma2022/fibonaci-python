class number:
    def __init__(self, n):
        self.n = n
    def __str__(self):
        return f"number: {self.n}"
    def __len__(self):
        return 1

num = number(10)
print(num)
print(len(num))