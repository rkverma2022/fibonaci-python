class person:
    company = "google"

    def getsalary(self):
        print(f"I'm getting: {self.salary}")

class employee(person):
    company = "microsoft"

    def getsalary(self):
        super().getsalary()
        print(f"salary: {self.salary}")

class programmer(employee):
    
    def language(self):
        super().getsalary()
        print(f"I know: {self.lang}")

p = person()
p.salary = 200
e = employee()
e.salary = 100
pr = programmer()
pr.lang = "python"
pr.salary = 999

pr.language()


