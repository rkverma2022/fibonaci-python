class employee:
    def info(self):
        print(f"your name: {self.name} marks: {self.marks}")


class program(employee):
    def location(self):
        
        print(f"your location: {self.area}")

e = employee()
p = program()
e.name = "harry"
e.marks = 29
p.area = "chowk"

p.name = "hello"
p.marks = 399

e.info()

p.location()
p.info()