class employee:
    salary = 100

    @classmethod
    def change(cls, sal):
        cls.salary = sal

e = employee()
e.change(200)
print(employee.salary)