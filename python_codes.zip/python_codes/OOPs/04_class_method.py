class employee:
    employee = 'google'
    def getSalary(self):
        print(f"salary is: {self.salary} {self.employee}")

    def greet(self):
        print("Good morning sir")

    @staticmethod
    def greeting():
        print("good after noon")

rajesh = employee()
rajesh.salary = 1000
rajesh.getSalary()
#another way to write
'''employee.getsalary(rajesh)'''
print(rajesh.employee)

rajesh.greet()
employee.greeting()                