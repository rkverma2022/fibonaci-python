'''PascalCase
camelCase'''



class number:
    def sum(self):
        return (self.a + self.b)

num = number()
num.a = 10
num.b = 20
print(num.sum())