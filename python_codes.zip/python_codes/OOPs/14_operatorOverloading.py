class number:
    def __init__(self, num1):
        self.num1 = num1
    
    def __add__(self, num2):
        print("adding")
        return self.num1 + num2.num1
    
    def __sub__(self, num2):
        print("subtracting")
        return self.num1 - num2.num1
    
    def __mul__(self, num2):
        print("multiplying")
        return self.num1* num2.num1
    
    def __truediv__(self, num2):
        print("division")
        return self.num1/num2.num1
    
    def __floordiv__(self, num2):
        print("floor division")
        return self.num1//num2.num1

n1 = number(12)
n2 = number(8)
sum= n1 + n2
print(sum)

sub = n1 - n2
print(sub)

mul = n1*n2
print(mul)

div = n1/n2
print(div)

di = n1/n2
print(di)
