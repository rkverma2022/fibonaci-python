class person:
    company = "google"
    def __init__(self):
        print("I'm in person class")

    def getsalary(self):
        print(f"I'm getting: {self.salary}")

class employee(person):
    company = "microsoft"
    def __init__(self):
        super().__init__()
        print("I'm in employee class")

    def getsalary(self):
        super().getsalary()
        print(f"salary: {self.salary}")

class programmer(employee):
    
    def __init__(self):
        super().__init__()
        print("I'm in programmer class")

    def language(self):
        super().getsalary()
        print(f"I know: {self.lang}")

pr = programmer()




