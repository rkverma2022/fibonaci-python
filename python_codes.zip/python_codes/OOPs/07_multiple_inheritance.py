class father:
    god = "Hanuman"

    def fworship(self):
        print(f"father worship: {self.god}")

class grandfather:
    god = "Siya-Ram"

    def gworship(self):
        print(f"gfather worship: {self.god}")

class child(father, grandfather):
    godess = "Durga"

    def pray(self):
        print(f"I worship: {self.godess}")

f = father()
g = grandfather()
c = child()

print(c.god)
print(c.pray())
print(c.fworship())
print(c.gworship())