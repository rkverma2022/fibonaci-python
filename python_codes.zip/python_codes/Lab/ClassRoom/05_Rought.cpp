#include<iostream>
#include<fstream>
using namespace std;

int main()
{
    ofstream outfile;
    outfile.open("myfile.txt");
    outfile<< "program"<<endl;
    outfile.close();
    return 0;
}