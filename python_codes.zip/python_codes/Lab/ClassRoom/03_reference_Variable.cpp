#include<iostream>
using namespace std;
void f(int &p)
{
    cout<<p<<endl;
}

int main()
{
    int kalia_patil= 10;
    cout<<kalia_patil<<endl;
    int &kp = kalia_patil;
    cout<<kp<<endl;

    kp += 20;
    cout<<kp<<endl;
    f(kalia_patil);
    return 0;
}