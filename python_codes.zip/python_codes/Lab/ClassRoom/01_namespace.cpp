#include<iostream>
using namespace std;
namespace xyz
{
    void f()
    {
        cout<<"xyz "<<endl;
    } 
}
namespace abc
{
    void g()
    {
        cout<<"abc "<<endl;
    } 
}
using namespace xyz;
using namespace abc;
int main()
{
    f();
    g();
    return 0;
}