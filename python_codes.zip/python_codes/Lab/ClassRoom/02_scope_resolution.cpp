#include<iostream>
using namespace std;
namespace xyz
{
    void f()
    {
        cout<<"In xyz "<<endl;
    } 
}
namespace abc
{
    void g()
    {
        cout<<"In abc "<<endl;
    } 
}

namespace ghi
{
    void f()
    {
        cout<<"In ghi"<<endl;
    }
}

int main()
{
    xyz::f();
    abc::g();
    ghi::f();
    return 0;
}