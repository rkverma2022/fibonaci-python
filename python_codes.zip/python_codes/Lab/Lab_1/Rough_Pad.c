#include<stdio.h>
#include<math.h>
int main()
{
    int a = 10;
    int idx = 1 + (int) log3 (9);
    printf("%f",(float)idx);
    return 0;
}