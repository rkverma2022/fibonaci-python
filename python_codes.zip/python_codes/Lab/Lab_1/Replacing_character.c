#include<stdio.h>


void replace_char_c1_by_c2(char *ch, char c1, char c2)
{
    if(*ch == '\0')     //base case
        return;
    if(*ch == c1)
        *ch = c2;
    replace_char_c1_by_c2(++ch, c1, c2);
}
int main()
{
    char str[25];
    printf("enter string: ");
    fgets(str, 25, stdin);
    
    printf("enter c1 and c2: ");
    char c1, c2;
    scanf("%c %c",&c1,&c2);
    //function call
    replace_char_c1_by_c2(str, c1, c2);
    //updated string
    printf("%s", str);
    return 0;
}