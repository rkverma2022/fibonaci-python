#include<stdio.h>

int find_max(int *ptr, int n, int max)
{
    if(n==0)
        return max;
    if(max < *ptr)
        max = *ptr;
    return find_max(++ptr, --n, max);
}
int main()
{
    int n;
    printf("no. of integers: ");
    scanf("%d",&n);
    int list[n];
    int i;
    for(i=0;i<n;i++)
        scanf("%d",&list[i]);
    printf("The max element is: %d",find_max(list, n, list[0]));
    return 0;
}