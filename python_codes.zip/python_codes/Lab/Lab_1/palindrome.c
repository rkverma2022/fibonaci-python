#include<stdio.h>

char Is_palindrome(char *ch, int n, int i)
{
    if(n == 0 || n==1 || i==n)
        return 'Y';
    if(ch[i]==ch[n])
        return 'N';
    return Is_palindrome(ch, --n, ++i);
}

int no_of_letter(char *ptr , int n)
{
    if(*ptr=='\0')
        return n;
    
    return no_of_letter(++ptr, ++n); 
}
int main()
{
    char str[30];
    printf("Enter String: ");
    scanf("%s",&str);
    int n = no_of_letter(str, 0);
    printf("%d\n",n);
    printf("%c",Is_palindrome(str, n, 0));
    return 0;
}