#include<stdio.h>
#include<stdlib.h>

typedef struct  node
{
    int data;
    struct node* next;
}node;

struct node* sortLL(node* Head, node * temp)
{
    if(temp->data < Head->data)
    {
        temp->next = Head;
        return temp;
    }
    if(temp->data >= Head->data && temp->data < Head->next->data)
    {
        Head->next = temp;
        return Head;
    }
    return sortLL(Head->next, temp);
}

void printLL(node* head)
{
    if(head == NULL)
        return;
    printf("%d\t",head->data);
    printLL(head->next);
    return;
}
int main()
{
    struct node* Head = NULL;
    Head = malloc(sizeof(node));
    Head->next = NULL;
    int n;
    printf("no. of nodes: ");
    scanf("%d",&n);
    printf("enter the data: ");
    scanf("%d",&Head->data);

    int flag;
    printf("Add node? ");
    scanf("%d",&flag);
    while (flag == 1)
    {
        node* temp = NULL;
        temp = malloc(sizeof(node));
        temp->next = NULL;
        printf("Enter Data: ");
        scanf("%d",&temp->data);
        Head = sortLL(Head, temp); flag =0;
        printf("Add node? ");
        scanf("%d",&flag);
    }

    //print sorted LL
    printLL(Head);
    
    return 0;
}