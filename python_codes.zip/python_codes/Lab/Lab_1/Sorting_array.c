#include<stdio.h>

void sort(int arr[], int n, int i);
int minOfarr(int arr[], int n, int i, int k);
void swap(int *a, int *b);

int main()
{
    int n;
    printf("Enter Nu. of integers: ");
    scanf("%d",&n);
    int list[n],i;
    
    printf("Enter Elements: ");
    for(i=0;i<n;i++)
    {
       scanf("%d",&list[i]) ;
    }

    sort(list, n, 0 );

    for(i=0; i<n; i++)
    {
        printf("%d\t",list[i]);
    }
}

void sort(int arr[], int n, int i)
{
    if(n == i)
        return;
    
    int k =i; //index of min
    k = minOfarr(arr, n, i, k);
    swap(&arr[i], &arr[k]);

    //recursion
    sort(arr, n, ++i);
}

int minOfarr(int arr[], int n, int i, int k)
{
    int min = arr[i];
    for(i; i<n; i++)
    {
        if(min > arr[i])
        {
            min = arr[i];
            k = i;
        }
    }
    return k;
}

void swap(int *a, int *b)
{
    int temp = *a;
    *a = *b;
    *b = temp;
}