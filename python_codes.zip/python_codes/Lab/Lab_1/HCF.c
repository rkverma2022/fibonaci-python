#include<stdio.h>
int HCF( int n1, int n2)
{
    if(n1%n2 == 0)
        return n2;
    if(n1>n2)
        return HCF(n1, n1%n2);
    else
        return HCF(n2%n1, n1);
}
int main()
{
    int n1, n2;
    scanf("%d  %d",&n1, &n2);
    printf("HCF(%d, %d): %d",n1, n2, HCF(n1,n2));
    return 0;
}