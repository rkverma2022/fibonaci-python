#include<stdio.h>

// #define char 'true' = 1;
// #define char 'false' = 0;
char search(int *ele, int key, int n)
{
    if(*ele == key)
        return 'Y';
    if(n==0)
        return 'N';
    return search(++ele, key, --n);
}
int main()
{
    int n;
    printf("no. of ele: ");
    scanf("%d",&n);
    printf("elements: ");
    int list[n];
    int i;
    for(i=0; i<n; i++)
    {
        scanf("%d",&list[i]);
    }
    int key;
    printf("Enter key nu: ");
    scanf("%d",&key);
    printf("%c",search(list, key, n));
    return 0;
}