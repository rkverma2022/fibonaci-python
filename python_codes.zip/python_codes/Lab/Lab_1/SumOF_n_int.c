#include<stdio.h>
int Sum(int n)
{
    if(n==0)
        return 0;
    return (n + Sum(n-1));
}
int main()
{
    unsigned int n;
    scanf("%d",&n);
    printf("Sum(%d) = %d",n,Sum(n));
    return 0;
}