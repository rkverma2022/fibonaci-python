#include<stdio.h>
#include<math.h>
#include<stdlib.h>

int findLargestNode(int m , int idx, int A[]);

int main()
{
    int m;
    printf("Num. of Nodes: ");
    scanf("%d",&m);
    int A[m + 1];

    int i;
    for(i=1; i< m+1; i++)
        A[i] = i;
    
    int n;
    printf("Degree of the tree: ");
    scanf("%d",&n);

    int idx;
    idx = 1 +  (log10 (m))/ log10 (n) ;
    
    int largest_int = findLargestNode(m, idx, A);
    
    printf("%d", largest_int);
    return 0;
}

int findLargestNode(int m, int idx, int A[])
{
    if(m == idx )
        return A[idx];

    return findLargestNode(m, ++idx, A); 
}
