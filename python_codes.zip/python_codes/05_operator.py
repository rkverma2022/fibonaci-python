#arithmatic

#comparison operator
# print(5>3)
# print(5<2)
# print(5==9)

# #logical operator
# bool = True
# bool1 = False
# print(bool)
# print(not bool1)
# print(bool and bool1)
# print(bool or bool1)