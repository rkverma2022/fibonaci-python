print(3>2)      #it will return bool value
print(3<2)
print(3==2)
print(3!=2)