old_age=input("ENTER YOUR OLD AGE: ")
new_age=int(old_age)+2;                      #we can't concatenate str to integer THAT'S why we need to convert our string to int(str) variable
                                      #Any value can be converted into the following datatype using respective function
                                        #float()   str()        bool()      int()
print(old_age, new_age);
print(bool(new_age))
print(str(new_age))
print(float(new_age))