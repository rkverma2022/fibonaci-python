i=1;
while i<=5:
    print(i*"*")            #it concatenate the string i time
    i+=1            #it don't recognise i++ 

for j in range(5):
    print(j+1)
    