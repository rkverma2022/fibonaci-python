name = "James Webb Space Telescope, World largest and most advanced machine, dedicated to reveals the truth behind our myth and helping humanity to think beyond our thinking power"
print('J' in name)