number = range(5)   # a function which give nuber: rang[0, 5)
print(number)