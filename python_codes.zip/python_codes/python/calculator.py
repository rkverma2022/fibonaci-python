n1 = int(input("Enter first nu: "))
operator=input("Enter: +, - , *, **, /, //, %  ")
n2=int( input("Enter second num: "))
if(operator=='+'):
    print(n1+ n2)
elif operator=='-':
    print(n1- n2)
elif operator=='*':
    print(n1*n2)
elif operator=='**':
    print(n1**n2)
elif operator=='/':
    print(n1/n2)
elif operator=='//':
    print(n1//n2)
elif operator=='%':
    print(n1%n2)
else: print("INVALID")