name="Anushka Verma"
print(name.upper())     #it's not changing the value stored at the address of name, it's like a function which is taking the string and changing all character's ASCII value by 97-65=32

print(name)

#find()   to find substring or character
#find() return the starting index of value
#find()     if that particular value is not present then it will return -1
print(name.find('s'));    
print(name.find("Verma"))     
print(name.find('a')) ;     #index of first matching will be return


#name.replace(str1,str2)         this function has not used pointer to change the value at it's address
print(name.replace("Verma", "An Astrophysicist"))
print(name)