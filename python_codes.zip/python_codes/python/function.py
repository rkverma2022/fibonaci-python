#1. in_built function           int() str() bool()     float()
#2. Module function             math module
#3. User_define Function
                                #Module function
import math
print(dir(math))            # function present in math module

#how to use it    i.e.            from math import sqrt
from math import sqrt
print(sqrt(9))

#to use any function present in that module
from math import*
print(pow(2,3))

                                #user define function
        #def function_name(parameters):
def print_sum(first,second,third=9):
    print(first+second)
    print(third-first)

print_sum(1,2)


###
def MyFun():  
    print("Hello World")  
    print(" Welcome to the JavaTpoint")  
  
MyFun() # Call Function to print the message. 