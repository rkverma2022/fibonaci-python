first=input("Enter first nu: ")         #2
second=input("Enter second nu: ")       #3
sum = first+second                      #23  because: it's treating like a string and both string has concatenated
print(sum)

sum=int(first)+int(second)              #5
print(sum)

print(5-7)

print(10/2)          #5
print(2/10)           #0.2      floating value
print(2//10)            #0      integer value
print(5//2)           #2

print(5*2)              # one *  multiplication
print(5**2)             #double ** square
# print(5***2)     invalid
