marks={"Physics": 1, "chemistry": 2}
print(marks)

#disconary have different kind of indexing
print(marks["Physics"])

marks["Math"]=3
print(marks)


#we can change the data 
marks["chemistry"]=0
print(marks)