name=input("What is your lovely name? ")       #input()  to take input from user
print("HELLO "+ name);          #concatenation,, strcat(first, second) in cpp

