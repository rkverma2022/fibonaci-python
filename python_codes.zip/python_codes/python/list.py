marks=[1,2,3,4,5]     #list
print(marks)        

print(marks[1])
print(marks[-1])        #counting starting from end

print(marks[0:2])       #printing element from 0th index to <2nd index

for score in marks:         #for loop in list
    print(score)
    
    
#list.append(elem)     to add an element at end of the list
#list.insert(inded,elem)    to add an eleent at our choise
marks.append(6)
print(marks)

marks.insert(0,0)
print(marks)

print(5 in marks)       #checking 5 is in list or not

#len(list)      
print(len(marks))

i=0
while i <len(marks):
    print(marks[i])
    i+=2
    

#list.count(elem)     returns the freq of elem in list  
print(marks.count(5))     

#marks.clear()        to make empty the list
marks.clear()
print(marks)   

