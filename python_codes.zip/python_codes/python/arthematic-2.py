i=5
i+=2
print(i)

#operator precidence
print(2+3*5)