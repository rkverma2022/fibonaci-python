print(2>3 or 2>1)       # logical or   and    not
print(4>5 and 4<9)
print(not 2>90)

age=1
if(age>=18):
    print("you are an adult")
    print("you can vote")
elif age<18 and age>3 :
    print("you are in school")
else:
    print("u are a child")
