print("Hello World");


name= "Rajkumar Verma";
print(name);

age=21;
print(age);

name="CST"          
age=99.8
print(name,age);

is_adult=True
print(is_adult)

name="Tony Stark";
age=51;
genius=True;
print(name, age, genius);
