student=["Anushka","Jyoti","Vivek","Nikhil","Ravi","Radhika"]
for stu in student:
    if stu=="Vivek":
        continue
    if stu=="Ravi":
        break
    print(stu)
