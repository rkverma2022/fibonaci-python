#we can not modify or assign new value to the tuple, it is mute. tuple_name = (elem)
marks=(1,2,3,4,5,4,4,4,4)
print(marks)

# marks.append(6)
# print(marks)     it's throwing error

# marks.insert(4,100)   No changes are allowed in tuple
# print(marks)


#tuple.count(elem)      it returns the frquency of elem in tuple or list
print(marks.count(4))

#tuple.index(elem)   it returns the index of elem
print(marks.index(5))

#sets
roll={1,2,3,4,5}
# print(roll[0])            we can't access the set by index, there is no indexing for set
print(roll)

for r in roll:
    print(r)
    r+=1

#()  for tuple
#{}  for sets
#[]  for list

TUPLE= "Hello", "Scientist"         #BY DEFAULT IT IS tuple, we need not to put parenthesis in caseof tuple
print(TUPLE)