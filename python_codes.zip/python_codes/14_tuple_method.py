t = (1,2,4,1,5,1,5,1)

print(t.count(1))

print(t.index(1))
