a = {4,5,2,6,0,0}
print(type(a))
print(a)

#create empty set
b = {}      #--> it's empty dictionary
print(type(b))

#syntax to create empty set

c = set()
print(type(c))