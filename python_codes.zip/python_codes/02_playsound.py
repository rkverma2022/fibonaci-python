from playsound import playsound
list = ['masu.mp3']

for s in list:
    playsound(str(s))