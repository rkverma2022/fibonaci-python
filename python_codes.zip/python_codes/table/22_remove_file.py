import os
for i in range(3,21):
    os.remove(f"table{i}.txt")