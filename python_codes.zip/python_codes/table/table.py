for i in range(2,21):
    with open(f"table{i}.txt", 'w') as a:
        for j in range(1,11):
            a.write(str(i*j)+ '\n')
    