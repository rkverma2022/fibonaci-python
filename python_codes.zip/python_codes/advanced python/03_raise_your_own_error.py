def g(x):
    try:
        return int(x) + 1
    except:
        raise ValueError("Please, ...it's not good")


a = g("39")
print(a)

a = g("sl90")
print(a)
