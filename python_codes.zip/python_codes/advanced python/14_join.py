l = ["apple", "grapes", "pineapple", "orange"]

sentence = "\n".join(l)
print(sentence)
print(type(sentence))
