


try:
    a = input("Enter a number ")
    a = int(a)
    c = 1/a
    print(c)
except ValueError as e:
    print("Please Enter a valid value")

except ZeroDivisionError as e:
    print("Make sure, not devide by zero")

except:
    print("error occured")

print("Thanks")
