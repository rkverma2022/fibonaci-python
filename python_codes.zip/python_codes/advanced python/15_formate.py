name = "Lucky"
favorite = "Playing Game"
sis = "Anushka"
a = "{} 's extracurricular activities is {} and his sister is {}".format(name, favorite, sis)
b = "{2} 's extracurricular activities is {1} and her brother is {0}".format(name, favorite, sis)
print(a)
print(b)
