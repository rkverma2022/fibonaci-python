try:
    i = int(input("Enter num: "))
    c = 1/i
except Exception as e:
    print(e)
else:
    print("Try has run")