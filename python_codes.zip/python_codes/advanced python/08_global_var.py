a = 48

def f():
    global a
    a = 29
    print(a)

if __name__ == '__main__':
    f()
    print(a)
