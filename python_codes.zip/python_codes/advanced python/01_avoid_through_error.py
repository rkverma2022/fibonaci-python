while (True):
    a = input("Enter the number: ")
    if a=='q':
        break
    try:
        if a>6:
            print("your number is greater than 6")
    except Exception as e:
        print(e)