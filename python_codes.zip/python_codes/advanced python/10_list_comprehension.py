a = [2, 5,3,55, 93,234, 540, 29, 94, 92, 28, 48, 20]

# b = []
# for item in a:
#     if item%2==0:
#         b.append(item)
# print(b)

#shortcut to write above

b = [i for i in a if i%2==0]
print(b)

#set
s = {i for i in a}
print(s)

