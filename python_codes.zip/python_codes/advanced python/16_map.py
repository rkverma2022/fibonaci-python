# l = [1, 2, 3]
# def square(num):
#     return num*num
# print(list(map(square, l)))

l = set(map(int, input("Enter ")))
print(l)

