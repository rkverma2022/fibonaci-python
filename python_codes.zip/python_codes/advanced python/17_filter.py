l = [1, 2, 4, 54, 5, 93]

def greaterthan(num):
    if num>5:
        return num
    else:
        return False

print(list(filter(greaterthan, l)))

g5 = lambda num: num>5

print(list(filter(g5, l)))
