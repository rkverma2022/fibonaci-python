try:
    i = int(input("Enter num: "))
    c = 1/i
except Exception as e:
    print(e)
    exit()
finally:                        #if our programm get exit then still we can run some task in finally:
    print("We are done")