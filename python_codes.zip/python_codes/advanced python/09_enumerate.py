list1 = [3, 53, False, "hey"]

# index =0
# for item in list1:
#     print(index, item)
#     index +=1

for index, item in enumerate(list1):
    print(index, item)
