import m06_file1

m06_file1.greet("Laali")
m06_file1.speak("Hellow, How are you?")