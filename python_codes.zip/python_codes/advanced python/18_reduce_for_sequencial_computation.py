from functools import reduce

'Reduce applies a rolliing computation to sequential pair of elements'
l = [1, 2, 3, 4]

sum = lambda a, b: a+b

print(reduce(sum, l))
