def greet(name):
    print(f"Good Morning, {name}")

def speak(word):
    print(f"Your word is: {word}")

'''entry point'''
if __name__ == '__main__':
    n = input("Enter the name: ")
    greet(n)
