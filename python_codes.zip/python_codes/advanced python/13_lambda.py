# def fun(a):
#     return a+5
fun = lambda a: a+5
square = lambda a: a*a
x = 555
print(fun(x))
print(square(x))
