a = 38
b = 10
print(a%b)