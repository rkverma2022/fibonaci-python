a = '583'
#print(type(a))
print(float(int(a) + 583))

b = input("Enter Nu: ")
print(type(b), ' ', float(b) + 4)