story = '''once upon a time,\n there was an scientist, named Rajkumar Verma'''

#string function
print(len(story))
print(story.endswith('Verma'))
print(story.count('R'))
print(story.capitalize())  #--> capitalize first char
print(story.find("Rajkumar")) #--> give index
print(story.replace("scientist",'great scientist'))
