print('''Twinkle, twinkle, little star,
How I wonder "what" you are!
Up above the world so high,
Like a 'diamond' in the sky.
''')