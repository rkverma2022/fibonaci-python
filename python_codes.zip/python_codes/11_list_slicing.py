c = [25, "dsa", False, 48.3]
print(c)
print(c[0])
print(c[:3])
print(c[2:])
print(c[-2])
print(c[::2])

