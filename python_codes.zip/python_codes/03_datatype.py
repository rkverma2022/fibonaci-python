_d = True
a = 20
b = 'hey'
c_1 = 60.3

print(type(_d) )
print(type(a))
print(type(b))
print(type(c_1))
