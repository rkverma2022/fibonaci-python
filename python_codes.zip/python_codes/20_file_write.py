f = open('sample.txt','w')
f.write("Hellow,\n I'm feeling\n ill. \nI miss my family a lot")
f.close()

f = open('sample.txt','a')
f.write("Hey \n I'm feeling\n ill. \nI miss my family a lot")
f.close()