# b = 'hello"s'
# # print(b)
c = '''hellow's"how'''
# # concatenating two string
# d = b + c
# print(d,'\n', d[0])
# #d[5] -->doesn't work

#string slicing
# print(c[2: 5])
# print(c[-1])
# print(c[:4])
# print(c[4:])
# print(c[-3:])

#character skipping
print(c[4::1])
print(c[4::2])